import streamlit as st
import os
import tempfile
import time
from main import TextProcessor
from typing import Optional
import base64
from pathlib import Path
from PIL import Image
from illustration_pipeline import IllustrationPipeline
from settings_manager import (
    settings_manager, get_api_key, set_api_key, has_api_key, save_settings,
    get_nanobanana_api_key, set_nanobanana_api_key,
    get_google_search_api_key, set_google_search_api_key,
    get_google_search_engine_id, set_google_search_engine_id,
    has_illustration_apis
)

# Функции для отображения результатов иллюстраций
def display_image_carousel(images_dir="extracted_images", max_images=10):
    """Отображает карусель изображений"""
    if not os.path.exists(images_dir):
        st.warning(f"📁 Директория {images_dir} не найдена")
        return

    image_files = [f for f in os.listdir(images_dir) if f.endswith(('.png', '.jpg', '.jpeg'))]
    if not image_files:
        st.info("📭 Изображения не найдены в директории extracted_images")
        return

    # Сортируем по имени файла (page_1_img_0.png, page_1_img_1.png, etc.)
    image_files.sort()

    # Ограничиваем количество изображений для отображения
    display_files = image_files[:max_images]

    st.subheader("🎠 Карусель извлеченных изображений")
    st.write(f"📊 Найдено изображений: {len(image_files)} | Показано: {len(display_files)}")

    # Создаем колонки для изображений (максимум 4 в ряд для лучшего отображения)
    cols_per_row = min(4, len(display_files))
    rows = (len(display_files) + cols_per_row - 1) // cols_per_row

    for row in range(rows):
        cols = st.columns(cols_per_row)
        for col_idx in range(cols_per_row):
            img_idx = row * cols_per_row + col_idx
            if img_idx < len(display_files):
                image_file = display_files[img_idx]
                with cols[col_idx]:
                    image_path = os.path.join(images_dir, image_file)
                    try:
                        # Используем st.image с правильными параметрами
                        st.image(image_path, caption=f"{image_file}", width=150, use_container_width=False)
                    except Exception as e:
                        st.error(f"❌ Ошибка загрузки {image_file}: {str(e)}")
                        # Показываем путь для диагностики
                        st.code(f"Путь: {image_path}")

    if len(image_files) > max_images:
        st.info(f"ℹ️ Показано {max_images} изображений из {len(image_files)}. Обработка продолжается...")

def display_found_images(results):
    """Отображает найденные изображения из поиска"""
    if not results.get("found_images"):
        return

    st.subheader("🖼️ Найденные изображения из поиска")

    # Проверяем и фильтруем найденные изображения
    valid_images = []
    for img in results["found_images"]:
        if isinstance(img, dict) and "pathology" in img and "source" in img:
            valid_images.append(img)
        else:
            st.warning(f"⚠️ Пропущено некорректное изображение: {type(img)} - {str(img)[:100]}...")

    if not valid_images:
        st.info("ℹ️ Не найдено корректных изображений для отображения")
        return

    # Группируем изображения по патологиям
    images_by_pathology = {}
    for img in valid_images:
        pathology = img["pathology"]
        if pathology not in images_by_pathology:
            images_by_pathology[pathology] = []
        images_by_pathology[pathology].append(img)

    # Отображаем по каждой патологии
    for pathology, images in images_by_pathology.items():
        with st.expander(f"🔍 {pathology} ({len(images)} изображений)", expanded=False):
            st.write(f"**Патология:** {pathology}")
            st.write(f"**Найдено изображений:** {len(images)}")

            # Отображаем изображения в колонках
            for i in range(0, len(images), 3):
                cols = st.columns(min(3, len(images) - i))
                for j in range(min(3, len(images) - i)):
                    img = images[i + j]
                    with cols[j]:
                        st.write(f"**Источник:** {img['source']}")
                        st.write(f"**Название:** {img['title']}")

                    # Показываем thumbnail если есть
                    if img.get("thumbnail") and isinstance(img["thumbnail"], str) and img["thumbnail"].startswith("http"):
                        try:
                            st.image(img["thumbnail"], caption=img["title"], use_column_width=True)
                        except Exception as e:
                            st.info(f"📷 Thumbnail недоступен: {str(e)}")
                    else:
                        st.info("📷 Thumbnail недоступен")

                        # Показываем ссылку если есть
                        if img.get("url"):
                            st.markdown(f"[🔗 Открыть изображение]({img['url']})")

                        if j < len(cols) - 1:  # Не добавляем разделитель для последнего в ряду
                            st.divider()

def display_detailed_logs(results):
    """Отображает подробные логи поиска"""
    st.subheader("🔍 Подробные логи поиска")

    # Логи обработки изображений
    if results.get("processed_images", 0) > 0:
        with st.expander("📊 Статистика обработки изображений", expanded=False):
            st.write("### Общая статистика:")
            st.write(f"- Всего изображений: {results.get('total_images', 0)}")
            st.write(f"- Обработано: {results.get('processed_images', 0)}")
            st.write(f"- Сгенерировано: {results.get('generated_images', 0)}")
            st.write(f"- Найдено в поиске: {results.get('search_results', 0)}")

            if results.get("pathologies_found"):
                st.write("### Найденные патологии:")
                for pathology in results["pathologies_found"]:
                    st.success(f"✅ {pathology}")

            if results.get("pathologies_missing"):
                st.write("### Патологии в розыске:")
                for pathology in results["pathologies_missing"]:
                    st.warning(f"⚠️ {pathology}")

    # Логи поиска по патологиям
    if results.get("pathologies_missing"):
        with st.expander("🔍 Детали поиска по патологиям", expanded=False):
            st.write("### Результаты поиска:")
            for pathology in results["pathologies_missing"]:
                st.write(f"• **{pathology}** - searching")
                st.info("Поиск выполнялся в базах TCIA и Google Images. Изображения не найдены, патология добавлена в список розыска.")

# Настройка страницы
st.set_page_config(
    page_title="Text Re-phraser",
    page_icon="📝",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Заголовок приложения
st.title("📝 Text Re-phraser")
st.markdown("**Инструмент для перефразирования текста в академическом стиле**")

# Боковая панель с информацией
with st.sidebar:
    st.header("ℹ️ Информация")
    st.markdown("""
    **Возможности:**
    - 📄 Поддержка форматов: PDF, TXT, MD, DOCX
    - 🎓 Перефразирование в академическом стиле
    - 💾 Сохранение оригинала и результата

    **Требования:**
    - Действующий API-ключ
    - Стабильное интернет-соединение
    """)

# Инициализация состояния приложения
def init_session_state():
    """Инициализация переменных состояния Streamlit"""
    if 'api_key_input' not in st.session_state:
        st.session_state.api_key_input = ""
    if 'api_key_saved' not in st.session_state:
        st.session_state.api_key_saved = has_api_key()
    if 'show_api_key_form' not in st.session_state:
        st.session_state.show_api_key_form = False
    if 'api_key_status' not in st.session_state:
        st.session_state.api_key_status = "🔑 API ключ " + ("сохранен" if has_api_key() else "не установлен")

# Основная функция приложения
def main():
    # Инициализация состояния
    init_session_state()

    # Создание вкладок
    tab1, tab2, tab3, tab4 = st.tabs(["🔄 Перефразирование", "📊 Результаты", "🎨 Иллюстрации", "⚙️ Настройки"])

    with tab1:
        st.header("🔄 Перефразирование текста")

        # Загрузка файла
        uploaded_file = st.file_uploader(
            "Выберите файл для обработки",
            type=["pdf", "txt", "md", "docx"],
            help="Поддерживаемые форматы: PDF, TXT, MD, DOCX"
        )

        # Ввод темы
        theme = st.text_input(
            "Тема текста",
            value="РЕНТГЕНОДИАГНОСТИКА ЗАБОЛЕВАНИЙ КОСТЕЙ И СУСТАВОВ",
            help="Укажите тематику текста для более точного перефразирования"
        )

        # Настройка уровня упрощения/уточнения текста
        st.markdown("#### 🎚️ Настройка стиля перефразирования")
        
        col1, col2 = st.columns([3, 1])
        with col1:
            temperature = st.slider(
                "Уровень творческого переформулирования",
                min_value=0.0,
                max_value=1.0,
                value=settings_manager.get("temperature", 0.4),
                step=0.1,
                help="Низкие значения (0.0-0.3): точное сохранение смысла, минимальные изменения\n"
                     "Средние значения (0.4-0.6): баланс между точностью и вариативностью\n"
                     "Высокие значения (0.7-1.0): более творческое переформулирование"
            )
        with col2:
            st.metric("Значение", f"{temperature:.1f}")
        
        # Описание выбранного уровня
        if temperature <= 0.3:
            st.info("📌 **Консервативный режим**: Максимальное сохранение оригинальной структуры и терминологии")
        elif temperature <= 0.6:
            st.info("⚖️ **Сбалансированный режим**: Умеренное перефразирование с сохранением академического стиля")
        else:
            st.info("✨ **Творческий режим**: Более вариативное переформулирование с сохранением смысла")

        # Переключатель добавления информации о новых исследованиях
        include_research = st.checkbox(
            "Добавлять информацию о новых исследованиях из разных известных источников",
            value=settings_manager.get("include_research", False),
            help="Включает добавление актуальной научной информации"
        )

        # Информация об API ключе
        if has_api_key():
            st.info("ℹ️ API ключ настроен. Переходите к загрузке файла и перефразированию.")
        else:
            st.warning("⚠️ API ключ не установлен. Пожалуйста, настройте его в разделе 'Настройки' перед началом работы.")

        # API ключ будет получен автоматически при обработке
        api_key = ""

        # Кнопка запуска
        if st.button("🚀 Начать перефразирование", type="primary", use_container_width=True):
            if not uploaded_file:
                st.error("❌ Пожалуйста, загрузите файл для обработки")
                return

            # Проверка API ключа
            if not has_api_key():
                st.error("❌ API ключ не настроен. Пожалуйста, настройте его в разделе 'Настройки'")
                return

            # Используем сохраненный ключ
            api_key = get_api_key()

            if not theme:
                st.error("❌ Пожалуйста, укажите тему текста")
                return

            # Создание прогресс-бара
            progress_bar = st.progress(0)
            status_text = st.empty()

            try:
                # Сохранение загруженного файла во временную директорию
                status_text.text("📁 Сохранение файла...")
                progress_bar.progress(10)

                with tempfile.NamedTemporaryFile(delete=False, suffix=f"_{uploaded_file.name}") as tmp_file:
                    tmp_file.write(uploaded_file.getvalue())
                    temp_file_path = tmp_file.name

                status_text.text("🔍 Извлечение текста...")
                progress_bar.progress(30)

                # Сохранение выбранных настроек
                settings_manager.set("temperature", temperature)
                settings_manager.set("include_research", include_research)
                
                # Создание процессора с дополнительными параметрами
                processor = TextProcessor(api_key, temperature=temperature, include_research=include_research)

                # Извлечение текста
                original_text = processor.read_input_file(temp_file_path)

                if not original_text:
                    st.error("❌ Не удалось извлечь текст из файла")
                    return

                status_text.text(f"🤖 Перефразирование текста (temperature: {temperature})...")
                progress_bar.progress(60)

                # Перефразирование
                paraphrased_text = processor.process_text(original_text, theme)

                if not paraphrased_text:
                    st.error("❌ Не удалось перефразировать текст")
                    return

                status_text.text("💾 Сохранение результатов...")
                progress_bar.progress(90)

                # Сохранение результатов
                output_dir = "output"
                os.makedirs(output_dir, exist_ok=True)

                # Сохранение оригинального текста
                with open(f"{output_dir}/original.txt", "w", encoding="utf-8") as f:
                    f.write(original_text)

                # Сохранение перефразированного текста
                with open(f"{output_dir}/paraphrased.txt", "w", encoding="utf-8") as f:
                    f.write(paraphrased_text)

                # Сохранение в session_state
                st.session_state.original_text = original_text
                st.session_state.paraphrased_text = paraphrased_text
                st.session_state.processing_complete = True

                progress_bar.progress(100)
                status_text.text("✅ Обработка завершена успешно!")
                time.sleep(1)
                status_text.empty()
                progress_bar.empty()

                st.success("🎉 Перефразирование завершено! Перейдите на вкладку 'Результаты' для просмотра.")

            except Exception as e:
                st.error(f"❌ Произошла ошибка: {str(e)}")
                st.info("💡 Рекомендации по устранению ошибки:\n"
                       "1. Проверьте корректность API-ключа\n"
                       "2. Убедитесь в стабильности интернет-соединения\n"
                       "3. Проверьте, что файл не поврежден\n"
                       "4. Попробуйте использовать VPN")

            finally:
                # Очистка временного файла
                if 'temp_file_path' in locals():
                    try:
                        os.unlink(temp_file_path)
                    except:
                        pass

    with tab2:
        st.header("📊 Результаты перефразирования")

        if 'processing_complete' in st.session_state and st.session_state.processing_complete:
            col1, col2 = st.columns(2)

            with col1:
                st.subheader("📄 Оригинальный текст")
                # Добавляем возможность скачать оригинальный текст
                st.download_button(
                    label="📥 Скачать оригинал",
                    data=st.session_state.original_text,
                    file_name="original.txt",
                    mime="text/plain"
                )
                st.text_area(
                    "Оригинальный текст:",
                    st.session_state.original_text,
                    height=400,
                    disabled=True
                )

            with col2:
                st.subheader("✨ Перефразированный текст")
                # Добавляем возможность скачать перефразированный текст
                st.download_button(
                    label="📥 Скачать результат",
                    data=st.session_state.paraphrased_text,
                    file_name="paraphrased.txt",
                    mime="text/plain"
                )
                st.text_area(
                    "Перефразированный текст:",
                    st.session_state.paraphrased_text,
                    height=400,
                    disabled=True
                )

            # Статистика
            st.markdown("---")
            st.subheader("📈 Статистика")
            col1, col2, col3 = st.columns(3)

            original_words = len(st.session_state.original_text.split())
            paraphrased_words = len(st.session_state.paraphrased_text.split())

            with col1:
                st.metric("Слов в оригинале", original_words)

            with col2:
                st.metric("Слов в результате", paraphrased_words)

            with col3:
                diff_percent = round((paraphrased_words - original_words) / original_words * 100, 1)
                st.metric("Изменение объема", f"{diff_percent}%")

        else:
            st.info("ℹ️ Выполните перефразирование на вкладке 'Перефразирование', чтобы увидеть результаты здесь.")

    with tab3:
        st.header("🎨 Автоматическая иллюстрация книги")
        
        # Проверка API ключей для иллюстраций
        if has_illustration_apis():
            st.success("✅ API ключи для иллюстраций настроены")
        else:
            st.warning("⚠️ Настройте API ключи для иллюстраций в разделе 'Настройки'")
        
        # Загрузка PDF для обработки иллюстраций
        uploaded_pdf = st.file_uploader(
            "Выберите PDF файл для обработки иллюстраций",
            type=["pdf"],
            help="Поддерживается только PDF формат"
        )
        
        if uploaded_pdf:
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("📋 Настройки обработки")
                
                auto_illustration = st.checkbox(
                    "Включить автоматическую иллюстрацию",
                    value=settings_manager.get("auto_illustration", False),
                    help="Автоматически генерировать и заменять иллюстрации"
                )
                
                illustration_quality = st.selectbox(
                    "Качество изображений",
                    ["high", "medium", "low"],
                    index=["high", "medium", "low"].index(settings_manager.get("illustration_quality", "high")),
                    help="Выберите качество генерируемых изображений"
                )
                
                brand_style = st.selectbox(
                    "Стиль брендинга",
                    ["medical", "modern", "classic", "minimalist"],
                    index=["medical", "modern", "classic", "minimalist"].index(settings_manager.get("brand_style", "medical")),
                    help="Выберите стиль для брендирования изображений"
                )
            
            with col2:
                st.subheader("🔍 Поиск источников")
                
                tcia_enabled = st.checkbox(
                    "Поиск в TCIA (DICOM)",
                    value=settings_manager.get("tcia_enabled", False),
                    help="Поиск DICOM файлов в The Cancer Imaging Archive (может быть недоступен)"
                )

                if tcia_enabled:
                    col_tcia1, col_tcia2 = st.columns([3, 1])
                    with col_tcia1:
                        tcia_timeout = st.slider(
                            "Таймаут TCIA (сек)",
                            min_value=10,
                            max_value=120,
                            value=settings_manager.get("tcia_timeout", 30),
                            help="Максимальное время ожидания ответа от TCIA API"
                        )
                    with col_tcia2:
                        if st.button("🚫 Отключить TCIA", help="Временно отключить TCIA из-за проблем с подключением"):
                            settings_manager.set("tcia_enabled", False)
                            st.success("✅ TCIA отключен. Перезагрузите страницу.")
                            st.rerun()

                    # Проверка статуса TCIA
                    with st.expander("🔍 Проверить статус TCIA"):
                        if st.button("Проверить доступность TCIA"):
                            with st.spinner("Проверка подключения..."):
                                try:
                                    import requests
                                    response = requests.get(
                                        "https://services.cancerimagingarchive.net/services/v4/TCIA/query/getCollectionValues",
                                        timeout=10
                                    )
                                    if response.status_code == 200:
                                        st.success("✅ TCIA API доступен")
                                    else:
                                        st.warning(f"⚠️ TCIA API вернул статус {response.status_code}")
                                except requests.exceptions.Timeout:
                                    st.error("❌ Таймаут при проверке TCIA")
                                except requests.exceptions.ConnectionError:
                                    st.error("❌ Ошибка подключения к TCIA")
                                except Exception as e:
                                    st.error(f"❌ Ошибка: {str(e)}")
                
                google_search_enabled = st.checkbox(
                    "Поиск в Google Images",
                    value=bool(get_google_search_api_key() and get_google_search_engine_id()),
                    disabled=not (get_google_search_api_key() and get_google_search_engine_id()),
                    help="Поиск клинических изображений в Google"
                )
            
            # Кнопка запуска обработки иллюстраций
            if st.button("🚀 Начать обработку иллюстраций", type="primary", use_container_width=True):
                if not has_illustration_apis():
                    st.error("❌ Настройте API ключи для иллюстраций в разделе 'Настройки'")
                else:
                    # Сохранение настроек
                    settings_manager.set("auto_illustration", auto_illustration)
                    settings_manager.set("illustration_quality", illustration_quality)
                    settings_manager.set("brand_style", brand_style)
                    settings_manager.set("tcia_enabled", tcia_enabled)
                    if tcia_enabled:
                        settings_manager.set("tcia_timeout", tcia_timeout)
                    
                    # Создание прогресс-бара
                    progress_bar = st.progress(0)
                    status_text = st.empty()
                    
                    try:
                        # Сохранение загруженного PDF
                        status_text.text("📁 Сохранение PDF файла...")
                        progress_bar.progress(10)
                        
                        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
                            tmp_file.write(uploaded_pdf.getvalue())
                            temp_pdf_path = tmp_file.name
                        
                        # Запуск pipeline иллюстраций
                        status_text.text("🎨 Запуск обработки иллюстраций...")
                        progress_bar.progress(30)

                        pipeline = IllustrationPipeline()
                        
                        # Обработка иллюстраций
                        status_text.text("🔍 Извлечение и анализ изображений...")
                        progress_bar.progress(60)

                        # Создаем placeholder для логов извлечения изображений
                        log_placeholder = st.empty()
                        extraction_logs = []
                        error_logs = []

                        def update_extraction_logs(message):
                            """Функция для обновления логов извлечения в реальном времени"""
                            extraction_logs.append(message)
                            # Показываем последние 5 сообщений
                            recent_logs = extraction_logs[-5:]
                            log_text = "\n".join(f"• {log}" for log in recent_logs)
                            if len(extraction_logs) > 5:
                                log_text = f"... и ещё {len(extraction_logs) - 5} изображений\n" + log_text

                            # Добавляем ошибки если есть
                            if error_logs:
                                recent_errors = error_logs[-3:]  # Показываем последние 3 ошибки
                                error_text = "\n".join(f"❌ {err}" for err in recent_errors)
                                if len(error_logs) > 3:
                                    error_text = f"... и ещё {len(error_logs) - 3} ошибок\n" + error_text
                                log_text += f"\n\n⚠️ Ошибки поиска:\n{error_text}"

                            log_placeholder.code(f"🔍 Логи извлечения изображений:\n{log_text}", language="text")

                        def update_error_logs(message):
                            """Функция для обновления логов ошибок"""
                            error_logs.append(message)
                            update_extraction_logs("")  # Обновляем отображение

                        # Показываем начальный статус
                        log_placeholder.code("🔍 Логи извлечения изображений:\n• Начинаем извлечение изображений...", language="text")

                        results = pipeline.process_illustrations(temp_pdf_path, progress_callback=update_extraction_logs, error_callback=update_error_logs)
                        
                        # Отображение результатов
                        status_text.text("📊 Анализ результатов...")
                        progress_bar.progress(90)
                        
                        st.success("✅ Обработка иллюстраций завершена!")

                        # Карусель изображений
                        display_image_carousel()

                        # Найденные изображения из поиска
                        display_found_images(results)

                        # Подробные логи поиска
                        display_detailed_logs(results)

                        # Статистика
                        col1, col2, col3, col4 = st.columns(4)
                        with col1:
                            st.metric("Всего изображений", results["total_images"])
                        with col2:
                            st.metric("Обработано", results["processed_images"])
                        with col3:
                            st.metric("Сгенерировано", results["generated_images"])
                        with col4:
                            st.metric("Найдено в поиске", results["search_results"])
                        
                        # Патологии в розыске
                        if results["pathologies_missing"]:
                            st.warning(f"⚠️ Патологии в розыске: {', '.join(results['pathologies_missing'])}")
                        
                        # Список патологий в розыске
                        search_list = pipeline.get_pathology_search_list()
                        if search_list:
                            with st.expander("📋 Список патологий в розыске"):
                                for pathology in search_list:
                                    st.write(f"• {pathology['pathology']} - {pathology['status']}")
                        
                        progress_bar.progress(100)
                        time.sleep(1)
                        status_text.empty()
                        progress_bar.empty()

                        # Очищаем placeholder с логами после завершения
                        log_placeholder.empty()
                        
                    except Exception as e:
                        st.error(f"❌ Произошла ошибка: {str(e)}")
                        st.info("💡 Рекомендации:\n"
                               "1. Проверьте настройки API ключей\n"
                               "2. Убедитесь в стабильности интернет-соединения\n"
                               "3. Проверьте, что PDF файл не поврежден")
                    
                    finally:
                        # Очистка временного файла
                        if 'temp_pdf_path' in locals():
                            try:
                                os.unlink(temp_pdf_path)
                            except:
                                pass
        
        else:
            st.info("ℹ️ Загрузите PDF файл для начала обработки иллюстраций")

    with tab4:
        st.header("⚙️ Настройки и информация")

        st.subheader("🔑 Управление API ключом")

        # Статус API ключа
        if has_api_key():
            st.success("✅ API ключ сохранен")
            masked_key = get_api_key()
            if len(masked_key) > 12:
                masked_key = f"{masked_key[:8]}...{masked_key[-4:]}"
            st.code(f"Ключ: {masked_key}", language=None)

            col1, col2 = st.columns(2)
            with col1:
                if st.button("🔄 Изменить API ключ", use_container_width=True):
                    st.session_state.show_api_key_settings = True
            with col2:
                if st.button("🗑️ Удалить API ключ", use_container_width=True):
                    settings_manager.clear_api_key()
                    st.session_state.api_key_saved = False
                    st.session_state.api_key_status = "🔑 API ключ не установлен"
                    st.success("🗑️ API ключ удален!")
                    st.rerun()
        else:
            st.warning("⚠️ API ключ не установлен")
            if st.button("➕ Добавить API ключ", use_container_width=True):
                st.session_state.show_api_key_settings = True

        # Форма для ввода API ключа
        if st.session_state.get('show_api_key_settings', False):
            with st.expander("🔑 Настройка API ключа", expanded=True):
                st.markdown("Введите ваш API ключ")

                new_api_key = st.text_input(
                    "API-ключ",
                    type="password",
                    help="Введите ваш API-ключ",
                    key="settings_api_key_input"
                )

                col1, col2, col3 = st.columns([1, 1, 1])
                with col1:
                    if st.button("💾 Сохранить", use_container_width=True):
                        if new_api_key and new_api_key.strip():
                            set_api_key(new_api_key.strip())
                            st.session_state.api_key_saved = True
                            st.session_state.api_key_status = "🔑 API ключ сохранен"
                            st.session_state.show_api_key_settings = False
                            st.success("🔑 API ключ успешно сохранен!")
                            st.rerun()
                        else:
                            st.error("❌ API ключ не может быть пустым")

                with col2:
                    if st.button("🔍 Проверить", use_container_width=True):
                        if new_api_key and new_api_key.strip():
                            st.info("🔍 Проверка API ключа...")
                            # Здесь можно добавить реальную проверку ключа через тестовый запрос
                            st.success("✅ Формат API ключа корректный")
                        else:
                            st.error("❌ Введите API ключ для проверки")

                with col3:
                    if st.button("❌ Отмена", use_container_width=True):
                        st.session_state.show_api_key_settings = False
                        st.rerun()

        st.markdown("---")

        # Настройки API ключей для иллюстраций
        st.subheader("🎨 API ключи для иллюстраций")
        
        # NanoBanana API
        if get_nanobanana_api_key():
            st.success("✅ NanoBanana API ключ настроен")
            if st.button("🗑️ Удалить NanoBanana API ключ", use_container_width=True):
                set_nanobanana_api_key("")
                st.rerun()
        else:
            st.warning("⚠️ NanoBanana API ключ не установлен")
            if st.button("➕ Добавить NanoBanana API ключ", use_container_width=True):
                st.session_state.show_nanobanana_settings = True
        
        # Google Custom Search API
        if get_google_search_api_key() and get_google_search_engine_id():
            st.success("✅ Google Custom Search API настроен")
            if st.button("🗑️ Удалить Google API ключи", use_container_width=True):
                set_google_search_api_key("")
                set_google_search_engine_id("")
                st.rerun()
        else:
            st.warning("⚠️ Google Custom Search API не настроен")
            if st.button("➕ Добавить Google API ключи", use_container_width=True):
                st.session_state.show_google_settings = True
        
        # Формы для настройки API ключей
        if st.session_state.get('show_nanobanana_settings', False):
            with st.expander("🎨 Настройка NanoBanana API", expanded=True):
                st.markdown("Введите ваш API ключ NanoBanana")
                
                nanobanana_key = st.text_input(
                    "NanoBanana API-ключ",
                    type="password",
                    help="Введите ваш API-ключ от NanoBanana",
                    key="nanobanana_api_key_input"
                )
                
                col1, col2 = st.columns(2)
                with col1:
                    if st.button("💾 Сохранить", use_container_width=True):
                        if nanobanana_key and nanobanana_key.strip():
                            set_nanobanana_api_key(nanobanana_key.strip())
                            st.session_state.show_nanobanana_settings = False
                            st.success("🎨 NanoBanana API ключ сохранен!")
                            st.rerun()
                        else:
                            st.error("❌ API ключ не может быть пустым")
                
                with col2:
                    if st.button("❌ Отмена", use_container_width=True):
                        st.session_state.show_nanobanana_settings = False
                        st.rerun()
        
        if st.session_state.get('show_google_settings', False):
            with st.expander("🔍 Настройка Google Custom Search API", expanded=True):
                st.markdown("Введите ваши API ключи Google Custom Search")
                
                google_key = st.text_input(
                    "Google Custom Search API-ключ",
                    type="password",
                    help="Введите ваш API-ключ от Google Cloud Console",
                    key="google_api_key_input"
                )
                
                google_engine_id = st.text_input(
                    "ID поисковой системы",
                    help="Введите ID вашей поисковой системы Google",
                    key="google_engine_id_input"
                )
                
                col1, col2 = st.columns(2)
                with col1:
                    if st.button("💾 Сохранить", use_container_width=True):
                        if google_key and google_engine_id and google_key.strip() and google_engine_id.strip():
                            set_google_search_api_key(google_key.strip())
                            set_google_search_engine_id(google_engine_id.strip())
                            st.session_state.show_google_settings = False
                            st.success("🔍 Google API ключи сохранены!")
                            st.rerun()
                        else:
                            st.error("❌ Все поля должны быть заполнены")
                
                with col2:
                    if st.button("❌ Отмена", use_container_width=True):
                        st.session_state.show_google_settings = False
                        st.rerun()
        
        st.markdown("---")

        st.subheader("🔧 Параметры обработки")
        current_temp = settings_manager.get("temperature", 0.4)
        st.markdown(f"""
        **Максимальная длина блока:** 500 символов  
        **Температура (текущая):** {current_temp} (от 0.0 до 1.0)  
        **Максимальные токены:** 2000  
        
        💡 **Информация о температуре:**
        - **0.0-0.3**: Консервативный режим - минимальные изменения
        - **0.4-0.6**: Сбалансированный режим - умеренное перефразирование
        - **0.7-1.0**: Творческий режим - более вариативное переформулирование
        """)

        st.subheader("📋 Инструкции по использованию")
        st.markdown("""
        1. **Загрузите файл** в поддерживаемом формате (PDF, TXT, MD, DOCX)
        2. **Укажите тему текста** для более точного перефразирования
        3. **Настройте уровень перефразирования** (temperature) с помощью слайдера:
           - 0.0-0.3: Консервативный режим
           - 0.4-0.6: Сбалансированный режим (рекомендуется)
           - 0.7-1.0: Творческий режим
        4. **Настройте API-ключ** в разделе "Настройки"
        5. **Нажмите кнопку** "Начать перефразирование"
        6. **Просмотрите результаты** на вкладке "Результаты"
        
        📖 **Подробнее:** см. файлы TEMPERATURE_FEATURE.md и USAGE_EXAMPLES.md
        """)

        st.subheader("🚨 Возможные проблемы")
        with st.expander("Распространенные ошибки и решения"):
            st.markdown("""
            **Ошибка API-ключа:**
            - Проверьте корректность ключа
            - Убедитесь, что ключ активен

            **Ошибка сети:**
            - Проверьте стабильность соединения

            **Ошибка файла:**
            - Проверьте формат файла
            - Убедитесь, что файл не поврежден
            """)

if __name__ == "__main__":
    main()