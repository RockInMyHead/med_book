#!/usr/bin/env python3
"""
Модуль автоматической иллюстрации книги
"""

import os
import json
import logging
import requests
import time
from typing import List, Dict, Optional, Tuple
from pathlib import Path
import fitz  # PyMuPDF
from settings_manager import (
    get_nanobanana_api_key, 
    get_google_search_api_key, 
    get_google_search_engine_id,
    settings_manager
)

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class IllustrationPipeline:
    """Класс для автоматической иллюстрации книги"""
    
    def __init__(self):
        """Инициализация pipeline иллюстраций"""
        self.nanobanana_api_key = get_nanobanana_api_key()
        self.google_api_key = get_google_search_api_key()
        self.google_engine_id = get_google_search_engine_id()
        self.tcia_enabled = settings_manager.get("tcia_enabled", True)
        self.auto_illustration = settings_manager.get("auto_illustration", False)
        self.illustration_quality = settings_manager.get("illustration_quality", "high")
        self.brand_style = settings_manager.get("brand_style", "medical")
        
        # Список патологий в розыске
        self.pathology_search_list = self._load_pathology_search_list()
        
        logger.info("IllustrationPipeline инициализирован")
        logger.info(f"NanoBanana API: {'✅' if self.nanobanana_api_key else '❌'}")
        logger.info(f"Google Search API: {'✅' if self.google_api_key and self.google_engine_id else '❌'}")
        logger.info(f"TCIA API: {'✅' if self.tcia_enabled else '❌'}")

    def _load_pathology_search_list(self) -> List[Dict]:
        """Загрузка списка патологий в розыске"""
        search_list_file = Path("pathology_search_list.json")
        if search_list_file.exists():
            try:
                with open(search_list_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Ошибка загрузки списка патологий: {e}")
        return []

    def _save_pathology_search_list(self):
        """Сохранение списка патологий в розыске"""
        search_list_file = Path("pathology_search_list.json")
        try:
            with open(search_list_file, 'w', encoding='utf-8') as f:
                json.dump(self.pathology_search_list, f, ensure_ascii=False, indent=2)
            logger.info(f"Список патологий сохранен в {search_list_file}")
        except Exception as e:
            logger.error(f"Ошибка сохранения списка патологий: {e}")

    def extract_images_from_pdf(self, pdf_path: str, progress_callback=None) -> List[Dict]:
        """Извлечение изображений из PDF с их описанием"""
        images = []
        try:
            doc = fitz.open(pdf_path)
            for page_num in range(len(doc)):
                page = doc[page_num]
                image_list = page.get_images()
                
                for img_index, img in enumerate(image_list):
                    xref = img[0]
                    pix = fitz.Pixmap(doc, xref)
                    
                    if pix.n - pix.alpha < 4:  # GRAY или RGB
                        # Получаем текст вокруг изображения для контекста
                        text_around = self._get_text_around_image(page, img)
                        
                        image_info = {
                            "page": page_num + 1,
                            "index": img_index,
                            "xref": xref,
                            "width": pix.width,
                            "height": pix.height,
                            "text_around": text_around,
                            "classification": self._classify_image(text_around),
                            "pathology": self._extract_pathology(text_around),
                            "file_path": f"extracted_images/page_{page_num+1}_img_{img_index}.png"
                        }
                        
                        # Сохраняем изображение
                        os.makedirs("extracted_images", exist_ok=True)
                        pix.save(image_info["file_path"])
                        images.append(image_info)

                        # Логируем извлечение изображения
                        log_message = f"Извлечено изображение: {image_info['file_path']}"
                        logger.info(log_message)

                        # Вызываем callback для обновления UI
                        if progress_callback:
                            progress_callback(log_message)
                    
                    pix = None
            
            doc.close()
            logger.info(f"Извлечено {len(images)} изображений из PDF")
            return images
            
        except Exception as e:
            logger.error(f"Ошибка извлечения изображений: {e}")
            return []

    def _get_text_around_image(self, page, img) -> str:
        """Получение текста вокруг изображения для контекста"""
        try:
            # Получаем прямоугольник изображения
            img_rect = page.get_image_rects(img[0])[0]
            
            # Расширяем область поиска текста
            expanded_rect = fitz.Rect(
                img_rect.x0 - 50, img_rect.y0 - 50,
                img_rect.x1 + 50, img_rect.y1 + 50
            )
            
            # Извлекаем текст из расширенной области
            text = page.get_textbox(expanded_rect)
            return text.strip()
            
        except Exception as e:
            logger.warning(f"Не удалось получить текст вокруг изображения: {e}")
            return ""

    def _classify_image(self, text_around: str) -> str:
        """Классификация изображения на энциклопедическое или клиническое"""
        text_lower = text_around.lower()
        
        # Ключевые слова для клинических изображений
        clinical_keywords = [
            "рентген", "снимок", "патология", "заболевание", "диагноз",
            "симптом", "лечение", "пациент", "клинический", "медицинский",
            "анализ", "исследование", "томография", "ультразвук", "мрт"
        ]
        
        # Ключевые слова для энциклопедических изображений
        encyclopedia_keywords = [
            "строение", "анатомия", "схема", "диаграмма", "иллюстрация",
            "структура", "орган", "система", "функция", "процесс"
        ]
        
        clinical_score = sum(1 for keyword in clinical_keywords if keyword in text_lower)
        encyclopedia_score = sum(1 for keyword in encyclopedia_keywords if keyword in text_lower)
        
        if clinical_score > encyclopedia_score:
            return "clinical"
        elif encyclopedia_score > 0:
            return "encyclopedia"
        else:
            return "unknown"

    def _extract_pathology(self, text_around: str) -> Optional[str]:
        """Извлечение названия патологии из текста"""
        # Простая эвристика для извлечения патологии
        # В реальной реализации можно использовать NLP
        text_lower = text_around.lower()
        
        # Список известных патологий
        pathologies = [
            "перелом", "остеопороз", "артрит", "артроз", "опухоль",
            "киста", "воспаление", "инфекция", "некроз", "склероз"
        ]
        
        for pathology in pathologies:
            if pathology in text_lower:
                return pathology
        
        return None

    def check_tcia_availability(self) -> bool:
        """Проверка доступности TCIA API"""
        try:
            response = requests.get(
                "https://services.cancerimagingarchive.net/services/v4/TCIA/query/getCollectionValues",
                timeout=5  # Быстрая проверка, 5 секунд
            )
            return response.status_code == 200
        except:
            return False

    def search_dicom_in_tcia(self, pathology: str, error_callback=None) -> List[Dict]:
        """Поиск DICOM файлов в TCIA по патологии"""
        if not self.tcia_enabled or not pathology:
            return []

        # Быстрая проверка доступности TCIA
        if not self.check_tcia_availability():
            logger.warning("TCIA API недоступен, пропуск поиска")
            if error_callback:
                error_callback("TCIA API недоступен")
            return []

        # Получаем таймаут из настроек, по умолчанию 30 секунд
        tcia_timeout = settings_manager.get('tcia_timeout', 30)
        max_retries = 2

        for attempt in range(max_retries):
            try:
                logger.info(f"Поиск в TCIA для патологии '{pathology}' (попытка {attempt + 1}/{max_retries})")

                # TCIA API endpoint
                base_url = "https://services.cancerimagingarchive.net/services/v4/TCIA/query"

                # Поиск коллекций по ключевым словам
                search_url = f"{base_url}/getCollectionValues"
                response = requests.get(search_url, timeout=tcia_timeout)

                if response.status_code == 200:
                    collections = response.json()
                    matching_collections = []

                    for collection in collections:
                        if pathology.lower() in collection.get("Collection", "").lower():
                            matching_collections.append(collection)

                    logger.info(f"Найдено {len(matching_collections)} коллекций в TCIA для патологии '{pathology}'")
                    return matching_collections
                else:
                    logger.warning(f"Ошибка запроса к TCIA API: {response.status_code}")
                    if attempt == max_retries - 1:  # Последняя попытка
                        return []

            except requests.exceptions.Timeout:
                error_msg = f"Таймаут подключения к TCIA (попытка {attempt + 1}/{max_retries}): {tcia_timeout} сек"
                logger.warning(error_msg)
                if attempt == max_retries - 1:  # Последняя попытка
                    if error_callback:
                        error_callback(error_msg)
                    return []
                # Ждем перед следующей попыткой
                time.sleep(2)

            except requests.exceptions.ConnectionError:
                error_msg = f"Ошибка подключения к TCIA (попытка {attempt + 1}/{max_retries})"
                logger.warning(error_msg)
                if attempt == max_retries - 1:  # Последняя попытка
                    if error_callback:
                        error_callback(error_msg)
                    return []
                # Ждем перед следующей попыткой
                time.sleep(2)

            except Exception as e:
                error_msg = f"Ошибка поиска в TCIA: {e}"
                logger.error(error_msg)
                if error_callback:
                    error_callback(error_msg)
                return []

        return []

    def search_images_google(self, query: str, num_results: int = 5, error_callback=None) -> List[Dict]:
        """Поиск изображений через Google Custom Search API"""
        if not self.google_api_key or not self.google_engine_id:
            logger.warning("Google Custom Search API не настроен")
            return []
        
        try:
            url = "https://www.googleapis.com/customsearch/v1"
            params = {
                "key": self.google_api_key,
                "cx": self.google_engine_id,
                "q": query,
                "searchType": "image",
                "num": num_results,
                "safe": "medium",
                "imgType": "photo",
                "imgSize": "large"
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                images = []
                
                for item in data.get("items", []):
                    image_info = {
                        "title": item.get("title", ""),
                        "url": item.get("link", ""),
                        "thumbnail": item.get("image", {}).get("thumbnailLink", ""),
                        "context": item.get("image", {}).get("contextLink", ""),
                        "size": item.get("image", {}).get("byteSize", 0)
                    }
                    images.append(image_info)
                
                logger.info(f"Найдено {len(images)} изображений в Google для запроса '{query}'")
                return images
            else:
                error_msg = f"Ошибка Google Custom Search API: {response.status_code}"
                logger.error(error_msg)
                if error_callback:
                    error_callback(error_msg)
                return []

        except Exception as e:
            error_msg = f"Ошибка поиска в Google: {e}"
            logger.error(error_msg)
            if error_callback:
                error_callback(error_msg)
            return []

    def generate_image_nanobanana(self, prompt: str, style: str = "medical") -> Optional[str]:
        """Генерация изображения через NanoBanana API"""
        if not self.nanobanana_api_key:
            logger.warning("NanoBanana API ключ не настроен")
            return None
        
        try:
            # Здесь будет интеграция с NanoBanana API
            # Пока заглушка
            logger.info(f"Генерация изображения через NanoBanana: {prompt}")
            logger.info(f"Стиль: {style}")
            
            # В реальной реализации:
            # 1. Отправка запроса к NanoBanana API
            # 2. Получение URL сгенерированного изображения
            # 3. Скачивание и сохранение изображения
            
            return None  # Заглушка
            
        except Exception as e:
            logger.error(f"Ошибка генерации изображения: {e}")
            return None

    def process_illustrations(self, pdf_path: str, progress_callback=None, error_callback=None) -> Dict:
        """Основной процесс обработки иллюстраций"""
        logger.info(f"Начало обработки иллюстраций для {pdf_path}")

        # Извлекаем изображения из PDF
        images = self.extract_images_from_pdf(pdf_path, progress_callback)
        
        results = {
            "total_images": len(images),
            "processed_images": 0,
            "generated_images": 0,
            "search_results": 0,
            "pathologies_found": [],
            "pathologies_missing": [],
            "found_images": []  # Список найденных изображений с патологиями
        }
        
        for image in images:
            logger.info(f"Обработка изображения: {image['file_path']}")
            
            if image["classification"] == "clinical" and image["pathology"]:
                # Поиск DICOM в TCIA
                dicom_results = self.search_dicom_in_tcia(image["pathology"], error_callback)
                
                if dicom_results:
                    results["search_results"] += len(dicom_results)
                    results["pathologies_found"].append(image["pathology"])
                    # Сохраняем найденные DICOM изображения
                    for dicom in dicom_results:
                        if isinstance(dicom, dict):
                            results["found_images"].append({
                                "pathology": image["pathology"],
                                "source": "TCIA",
                                "title": dicom.get("Collection", "DICOM Collection"),
                                "url": None,  # TCIA не предоставляет прямые URL изображений
                                "thumbnail": None
                            })
                        else:
                            logger.warning(f"Пропущен некорректный DICOM результат: {type(dicom)} - {dicom}")
                    logger.info(f"Найдены DICOM файлы для патологии: {image['pathology']}")
                else:
                    # Поиск в Google Images
                    google_results = self.search_images_google(
                        f"{image['pathology']} medical imaging x-ray",
                        error_callback=error_callback
                    )

                    if google_results:
                        results["search_results"] += len(google_results)
                        # Сохраняем найденные Google изображения
                        for google_img in google_results:
                            if isinstance(google_img, dict):
                                results["found_images"].append({
                                    "pathology": image["pathology"],
                                    "source": "Google Images",
                                    "title": google_img.get("title", "Medical Image"),
                                    "url": google_img.get("url"),  # Исправлено: было "link"
                                    "thumbnail": google_img.get("thumbnail")  # Исправлено: убираем лишний .get("src")
                                })
                            else:
                                logger.warning(f"Пропущен некорректный Google результат: {type(google_img)} - {google_img}")
                        logger.info(f"Найдены изображения в Google для патологии: {image['pathology']}")
                    else:
                        # Добавляем в список патологий в розыске
                        if image["pathology"] not in [p["pathology"] for p in self.pathology_search_list]:
                            self.pathology_search_list.append({
                                "pathology": image["pathology"],
                                "context": image["text_around"],
                                "date_added": str(Path().cwd()),
                                "status": "searching"
                            })
                            results["pathologies_missing"].append(image["pathology"])
                            logger.warning(f"Патология добавлена в розыск: {image['pathology']}")
            
            elif image["classification"] == "encyclopedia":
                # Генерация современной энциклопедической иллюстрации
                prompt = f"Modern medical illustration: {image['text_around'][:100]}"
                generated_image = self.generate_image_nanobanana(prompt, self.brand_style)
                
                if generated_image:
                    results["generated_images"] += 1
                    logger.info(f"Сгенерирована энциклопедическая иллюстрация")
            
            results["processed_images"] += 1
        
        # Сохраняем обновленный список патологий в розыске
        self._save_pathology_search_list()
        
        logger.info(f"Обработка завершена: {results}")
        return results

    def get_pathology_search_list(self) -> List[Dict]:
        """Получение списка патологий в розыске"""
        return self.pathology_search_list

    def clear_pathology_search_list(self):
        """Очистка списка патологий в розыске"""
        self.pathology_search_list = []
        self._save_pathology_search_list()
        logger.info("Список патологий в розыске очищен")

def main():
    """Тестовая функция"""
    pipeline = IllustrationPipeline()
    
    # Тест с существующим PDF
    pdf_path = "input/Кости_глава_1.pdf"
    if os.path.exists(pdf_path):
        results = pipeline.process_illustrations(pdf_path)
        print(f"Результаты обработки: {results}")
    else:
        print(f"Файл {pdf_path} не найден")

if __name__ == "__main__":
    main()
